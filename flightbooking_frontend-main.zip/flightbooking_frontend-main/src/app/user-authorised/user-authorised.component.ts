import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-authorised',
  templateUrl: './user-authorised.component.html',
  styleUrls: ['./user-authorised.component.css']
})
export class UserAuthorisedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
