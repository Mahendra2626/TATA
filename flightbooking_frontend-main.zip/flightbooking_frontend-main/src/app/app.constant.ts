export const server_url="http://localhost:8181";
//export const sharedSecret="xnW0eCTAOVIWKgdNucnBHTYjhZ2XIDMnSz3kXb20NU";
//export const server_url="https://yourawsurl.aws.com"