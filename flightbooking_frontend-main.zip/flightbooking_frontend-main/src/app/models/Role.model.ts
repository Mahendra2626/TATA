export class Role{

    public id!: number;
    public roleName!: string;
    public roleDesc!: string;
}