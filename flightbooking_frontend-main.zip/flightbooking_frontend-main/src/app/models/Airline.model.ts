export class Airline{

    public id!: number;

    public name!: string;

    public code!: string;

    public operationType!: string;

    public country!: string;
}