export class Airport{

    public id!: number;

    public name!: string;

    public code!: string;

    public state!: string;
}